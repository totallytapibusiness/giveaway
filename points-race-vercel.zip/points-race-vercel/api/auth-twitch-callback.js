const { redirect, baseUrl, checkState, isEligible } = require('../lib/util');
const { getSession, saveSession } = require('../lib/session');
const { registerUser } = require('../lib/data');

const back = (res, flag) => redirect(res, '/?auth=' + flag);

module.exports = async (req, res) => {
  try {
    const { code, state, error } = req.query || {};
    if (error || !code || !checkState(req, res, 'twitch', state)) return back(res, 'twitch_failed');
    const clientId = process.env.TWITCH_CLIENT_ID;
    const broadcaster = process.env.TWITCH_BROADCASTER_ID;

    const tokRes = await fetch('https://id.twitch.tv/oauth2/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        client_id: clientId,
        client_secret: process.env.TWITCH_CLIENT_SECRET,
        code,
        grant_type: 'authorization_code',
        redirect_uri: baseUrl(req) + '/api/auth-twitch-callback',
      }),
    });
    const tok = await tokRes.json();
    if (!tokRes.ok || !tok.access_token) return back(res, 'twitch_failed');
    const h = { Authorization: 'Bearer ' + tok.access_token, 'Client-Id': clientId };

    const meRes = await fetch('https://api.twitch.tv/helix/users', { headers: h });
    const me = ((await meRes.json()).data || [])[0];
    if (!meRes.ok || !me) return back(res, 'twitch_failed');

    // 200 = subscribed (gifted subs count), 404 = not subscribed. Anything else is an error.
    const subRes = await fetch(
      `https://api.twitch.tv/helix/subscriptions/user?broadcaster_id=${encodeURIComponent(broadcaster)}&user_id=${encodeURIComponent(me.id)}`,
      { headers: h }
    );
    if (subRes.status !== 200 && subRes.status !== 404) return back(res, 'twitch_failed');
    const sub = subRes.status === 200;

    const sess = getSession(req);
    sess.tw = { id: String(me.id), login: me.login, display: me.display_name, sub };
    saveSession(res, sess);
    if (isEligible(sess)) await registerUser(sess);
    back(res, sub ? 'twitch_ok' : 'twitch_not_sub');
  } catch (e) {
    back(res, 'twitch_failed');
  }
};
