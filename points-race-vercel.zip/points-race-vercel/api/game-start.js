const { json, jsonPost, isEligible, randId } = require('../lib/util');
const { getSession, sign } = require('../lib/session');
const { GAMES } = require('../lib/config');

// Starts a run. The token remembers when the run began, so a finished score can be sanity-checked.
module.exports = (req, res) => {
  try {
    const body = jsonPost(req, res);
    if (!body) return;
    const sess = getSession(req);
    if (!isEligible(sess)) return json(res, 403, { error: 'Connect and verify both accounts first.' });
    if (!GAMES[body.game]) return json(res, 400, { error: 'Unknown game.' });
    const token = sign({ k: 'g', u: sess.tw.id, g: body.game, t: Date.now(), id: randId(), exp: Date.now() + 15 * 60 * 1000 });
    json(res, 200, { token });
  } catch (e) {
    json(res, 500, { error: 'Server error.' });
  }
};
