const { cmd } = require('../lib/redis');
const { json, isEligible, isAdmin } = require('../lib/util');
const { getSession } = require('../lib/session');
const { getSettings, getOrnaments, getUser, today } = require('../lib/data');
const { GAMES, DAILY_PLAYS } = require('../lib/config');

// Everything the public page needs. The leaderboard is NOT in here, on purpose.
module.exports = async (req, res) => {
  try {
    const sess = getSession(req);
    const [settings, ornaments] = await Promise.all([getSettings(), getOrnaments(false)]);
    const eligible = isEligible(sess);

    let plays = null;
    let mine = null;
    if (eligible) {
      const ids = Object.keys(GAMES);
      const [vals, orn] = await Promise.all([
        cmd('MGET', ...ids.map((g) => `plays:${sess.tw.id}:${g}:${today()}`)),
        cmd('HGET', 'orn', sess.tw.id),
      ]);
      plays = {};
      ids.forEach((g, i) => (plays[g] = Math.max(0, DAILY_PLAYS - (parseInt(vals[i], 10) || 0))));
      try {
        const o = orn && JSON.parse(orn);
        if (o) mine = { s: o.s, c: o.c, d: o.d };
      } catch (e) {}
    }

    let winner = null;
    if (settings.reveal) {
      const top = await cmd('ZREVRANGE', 'lb', '0', '0');
      if (top && top[0]) {
        const u = await getUser(top[0]);
        winner = u ? u.name : null;
      }
    }

    const games = {};
    Object.keys(GAMES).forEach((g) => (games[g] = { tiers: GAMES[g].tiers, higher: GAMES[g].higher }));

    json(res, 200, {
      prize: settings.prize,
      endsAt: settings.endsAt,
      twitchUrl: settings.twitchUrl,
      discordUrl: settings.discordUrl,
      reveal: !!settings.reveal,
      placePts: settings.placePts,
      dailyPlays: DAILY_PLAYS,
      winner,
      games,
      ornaments,
      plays,
      mine,
      me: {
        twitch: sess.tw ? { display: sess.tw.display, sub: !!sess.tw.sub } : null,
        discord: sess.dc ? { name: sess.dc.name, member: !!sess.dc.member } : null,
        eligible,
        admin: isAdmin(sess),
      },
    });
  } catch (e) {
    json(res, 500, { error: 'The server is not set up yet. ' + e.message });
  }
};
