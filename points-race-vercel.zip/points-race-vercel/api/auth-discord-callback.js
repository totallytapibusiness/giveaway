const { redirect, baseUrl, checkState, isEligible } = require('../lib/util');
const { getSession, saveSession } = require('../lib/session');
const { registerUser } = require('../lib/data');

const back = (res, flag) => redirect(res, '/?auth=' + flag);

module.exports = async (req, res) => {
  try {
    const { code, state, error } = req.query || {};
    if (error || !code || !checkState(req, res, 'discord', state)) return back(res, 'discord_failed');

    const tokRes = await fetch('https://discord.com/api/oauth2/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        client_id: process.env.DISCORD_CLIENT_ID,
        client_secret: process.env.DISCORD_CLIENT_SECRET,
        grant_type: 'authorization_code',
        code,
        redirect_uri: baseUrl(req) + '/api/auth-discord-callback',
      }),
    });
    const tok = await tokRes.json();
    if (!tokRes.ok || !tok.access_token) return back(res, 'discord_failed');
    const auth = { Authorization: 'Bearer ' + tok.access_token };

    const meRes = await fetch('https://discord.com/api/users/@me', { headers: auth });
    const me = await meRes.json();
    if (!meRes.ok || !me.id) return back(res, 'discord_failed');

    // 200 means "this person is a member of the server", 404 means they are not.
    const mem = await fetch(`https://discord.com/api/users/@me/guilds/${process.env.DISCORD_GUILD_ID}/member`, { headers: auth });
    if (mem.status !== 200 && mem.status !== 404) return back(res, 'discord_failed');
    const member = mem.status === 200;

    const sess = getSession(req);
    sess.dc = { id: String(me.id), name: me.global_name || me.username, member };
    saveSession(res, sess);
    if (isEligible(sess)) await registerUser(sess);
    back(res, member ? 'discord_ok' : 'discord_not_member');
  } catch (e) {
    back(res, 'discord_failed');
  }
};
