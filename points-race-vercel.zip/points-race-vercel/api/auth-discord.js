const { json, redirect, baseUrl, newState } = require('../lib/util');

// Step 1 of "Connect Discord": send the visitor to Discord to approve.
// We ask only for their identity and for permission to see whether they are in OUR server.
module.exports = (req, res) => {
  try {
    const id = process.env.DISCORD_CLIENT_ID;
    if (!id) return json(res, 500, { error: 'DISCORD_CLIENT_ID is not set' });
    const state = newState(res, 'discord');
    const q = new URLSearchParams({
      client_id: id,
      response_type: 'code',
      redirect_uri: baseUrl(req) + '/api/auth-discord-callback',
      scope: 'identify guilds.members.read',
      state,
    });
    redirect(res, 'https://discord.com/oauth2/authorize?' + q.toString());
  } catch (e) {
    json(res, 500, { error: 'Server is not set up yet: ' + e.message });
  }
};
