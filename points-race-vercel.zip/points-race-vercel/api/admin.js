const { cmd } = require('../lib/redis');
const { json, jsonPost, isAdmin } = require('../lib/util');
const { getSession } = require('../lib/session');
const { getSettings, saveSettings, getOrnaments } = require('../lib/data');

const okUrl = (u) => u === '' || /^https?:\/\/\S{1,200}$/.test(u);

// Host-only. Who counts as the host is set with ADMIN_TWITCH_ID and/or ADMIN_DISCORD_ID.
module.exports = async (req, res) => {
  try {
    const sess = getSession(req);
    if (!isAdmin(sess)) return json(res, 403, { error: 'Host only.' });

    if (req.method === 'GET') {
      const flat = (await cmd('ZREVRANGE', 'lb', '0', '-1', 'WITHSCORES')) || [];
      const ids = [], pts = [];
      for (let i = 0; i < flat.length; i += 2) {
        ids.push(flat[i]);
        pts.push(Number(flat[i + 1]));
      }
      const users = ids.length ? await cmd('MGET', ...ids.map((i) => 'user:' + i)) : [];
      const board = ids.map((id, i) => {
        let u = {};
        try {
          u = users[i] ? JSON.parse(users[i]) : {};
        } catch (e) {}
        return { id, name: u.name || id, discord: u.dcName || '', pts: pts[i] };
      });
      return json(res, 200, { settings: await getSettings(), board, ornaments: await getOrnaments(true) });
    }

    const b = jsonPost(req, res);
    if (!b) return;

    if (b.action === 'settings') {
      const x = b.settings || {};
      const pp = Array.isArray(x.placePts) ? x.placePts.map((n) => Math.round(Number(n))) : [];
      if (pp.length !== 4 || pp.some((n) => !isFinite(n) || n < 0 || n > 100000)) return json(res, 400, { error: 'Points per place must be four numbers.' });
      const s = {
        prize: String(x.prize || '').slice(0, 80),
        endsAt: String(x.endsAt || '').slice(0, 32),
        twitchUrl: String(x.twitchUrl || '').trim(),
        discordUrl: String(x.discordUrl || '').trim(),
        reveal: !!x.reveal,
        placePts: pp,
      };
      if (!okUrl(s.twitchUrl) || !okUrl(s.discordUrl)) return json(res, 400, { error: 'Links must start with http:// or https://' });
      await saveSettings(s);
      return json(res, 200, { ok: true });
    }

    if (b.action === 'adjust') {
      const id = String(b.id || '');
      const delta = Math.round(Number(b.delta));
      if (!/^\d+$/.test(id) || !isFinite(delta) || Math.abs(delta) > 100000) return json(res, 400, { error: 'Bad adjustment.' });
      if ((await cmd('ZSCORE', 'lb', id)) === null) return json(res, 404, { error: 'No such entrant.' });
      await cmd('ZINCRBY', 'lb', delta, id);
      return json(res, 200, { ok: true });
    }

    if (b.action === 'removeUser') {
      const id = String(b.id || '');
      if (!/^\d+$/.test(id)) return json(res, 400, { error: 'Bad id.' });
      await cmd('ZREM', 'lb', id);
      await cmd('DEL', 'user:' + id);
      await cmd('HDEL', 'orn', id);
      return json(res, 200, { ok: true });
    }

    if (b.action === 'removeOrnament') {
      const id = String(b.id || '');
      if (!/^\d+$/.test(id)) return json(res, 400, { error: 'Bad id.' });
      await cmd('HDEL', 'orn', id);
      return json(res, 200, { ok: true });
    }

    json(res, 400, { error: 'Unknown action.' });
  } catch (e) {
    json(res, 500, { error: 'Server error.' });
  }
};
