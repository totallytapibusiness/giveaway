const { json, jsonPost } = require('../lib/util');
const { clearSession } = require('../lib/session');

module.exports = (req, res) => {
  if (!jsonPost(req, res)) return;
  clearSession(res);
  json(res, 200, { ok: true });
};
