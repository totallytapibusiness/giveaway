const { json, redirect, baseUrl, newState } = require('../lib/util');

// Step 1 of "Connect Twitch". The only permission requested is "read my subscriptions",
// which Twitch requires before it will tell us whether this person subscribes to your channel.
module.exports = (req, res) => {
  try {
    const id = process.env.TWITCH_CLIENT_ID;
    if (!id) return json(res, 500, { error: 'TWITCH_CLIENT_ID is not set' });
    const state = newState(res, 'twitch');
    const q = new URLSearchParams({
      client_id: id,
      redirect_uri: baseUrl(req) + '/api/auth-twitch-callback',
      response_type: 'code',
      scope: 'user:read:subscriptions',
      state,
    });
    redirect(res, 'https://id.twitch.tv/oauth2/authorize?' + q.toString());
  } catch (e) {
    json(res, 500, { error: 'Server is not set up yet: ' + e.message });
  }
};
