const { cmd } = require('../lib/redis');
const { json, jsonPost, isEligible } = require('../lib/util');
const { getSession } = require('../lib/session');
const { registerUser } = require('../lib/data');

// One ornament per verified person. Saving again replaces the old one.
module.exports = async (req, res) => {
  try {
    const body = jsonPost(req, res);
    if (!body) return;
    const sess = getSession(req);
    if (!isEligible(sess)) return json(res, 403, { error: 'Connect and verify both accounts first.' });
    const s = Number(body.s), c = Number(body.c), d = Number(body.d);
    if (!(Number.isInteger(s) && s >= 0 && s < 4 && Number.isInteger(c) && c >= 0 && c < 8 && Number.isInteger(d) && d >= 0 && d < 3)) {
      return json(res, 400, { error: 'That ornament is not valid.' });
    }
    await registerUser(sess);
    await cmd('HSET', 'orn', sess.tw.id, JSON.stringify({ name: sess.tw.display, s, c, d }));
    json(res, 200, { ok: true });
  } catch (e) {
    json(res, 500, { error: 'Server error.' });
  }
};
