const { cmd } = require('../lib/redis');
const { json, jsonPost, isEligible } = require('../lib/util');
const { getSession, verify } = require('../lib/session');
const { getSettings, registerUser, today } = require('../lib/data');
const { GAMES, placeOf, DAILY_PLAYS } = require('../lib/config');

module.exports = async (req, res) => {
  try {
    const body = jsonPost(req, res);
    if (!body) return;
    const sess = getSession(req);
    if (!isEligible(sess)) return json(res, 403, { error: 'Connect and verify both accounts first.' });

    const tk = verify(body.token);
    if (!tk || tk.k !== 'g' || tk.u !== sess.tw.id || !GAMES[tk.g]) return json(res, 400, { error: 'That run is not valid. Start a new one.' });
    const g = GAMES[tk.g];

    const score = Number(body.score);
    if (!Number.isInteger(score) || score < g.min || score > g.max) return json(res, 400, { error: 'That score was rejected.' });
    if ((Date.now() - tk.t) / 1000 < g.minSec) return json(res, 400, { error: 'That run finished too fast to count.' });

    const settings = await getSettings();
    if (settings.endsAt) {
      const end = Date.parse(settings.endsAt);
      if (!isNaN(end) && Date.now() > end) return json(res, 403, { error: 'The race is over.' });
    }

    // A run can only be turned in once.
    const fresh = await cmd('SET', 'used:' + tk.id, '1', 'NX', 'EX', '3600');
    if (!fresh) return json(res, 400, { error: 'That run was already counted.' });

    const place = placeOf(g, score);
    const key = `plays:${sess.tw.id}:${tk.g}:${today()}`;
    const n = await cmd('INCR', key);
    if (n === 1) await cmd('EXPIRE', key, '172800');
    if (n > DAILY_PLAYS) return json(res, 200, { place, points: 0, limited: true, left: 0 });

    const points = Number(settings.placePts[place]) || 0;
    await registerUser(sess);
    if (points) await cmd('ZINCRBY', 'lb', points, sess.tw.id);
    json(res, 200, { place, points, limited: false, left: Math.max(0, DAILY_PLAYS - n) });
  } catch (e) {
    json(res, 500, { error: 'Server error.' });
  }
};
