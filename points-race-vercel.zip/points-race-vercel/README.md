# Points Race

Holiday sweepstakes site: Twitch subscriber check, Discord server check, snow, a 3D community tree with
player-made ornaments, mini games that award points by place, and a private leaderboard only the host sees.

Everything runs on Vercel. There is no build step and nothing to install.

## How verification works

- **Twitch:** the visitor logs in with Twitch and approves "read my subscriptions". The server asks Twitch whether
  that account subscribes to your channel (gifted subs count).
- **Discord:** the visitor logs in with Discord and approves "see my server membership". The server asks Discord
  whether that account is in your server.
- Both results are stored in a signed cookie (3 days). The visitor must pass both before they can play or hang an ornament.
- Scores are checked on the server: a run must be started on the server, cannot finish faster than the game allows,
  cannot exceed what a person can reach, can be turned in only once, and earns points for only a few plays per day.
  A determined cheater can still fake a score inside those limits, so spot-check the top of the leaderboard.

## Setup (about 20 minutes)

### 1. Put the project on Vercel
1. Create a free account at vercel.com and a free GitHub account if you do not have one.
2. Make a new GitHub repository and upload everything in this folder (do not upload a `.env` file).
3. In Vercel choose **Add New > Project**, import that repository, leave all settings as they are, and deploy.
4. Note your address, for example `https://points-race.vercel.app`. If you add your own domain later, use that instead everywhere below.

### 2. Add the database
In your Vercel project open **Storage**, create an **Upstash Redis** database from the marketplace (free plan is enough),
and connect it to the project. This adds `KV_REST_API_URL` and `KV_REST_API_TOKEN` for you.

### 3. Create the Discord app
1. Go to discord.com/developers/applications and press **New Application**.
2. Under **OAuth2**, copy the **Client ID** and **Client Secret**.
3. Under **OAuth2 > Redirects**, add: `https://YOUR-SITE/api/auth-discord-callback`
4. Get your server ID: in Discord turn on Settings > Advanced > Developer Mode, then right-click your server icon and choose **Copy Server ID**.
5. Make a permanent invite link for your server (optional but recommended).
You do not need to add a bot.

### 4. Create the Twitch app
1. Go to dev.twitch.tv/console and press **Register Your Application**.
2. Name it, set **OAuth Redirect URL** to: `https://YOUR-SITE/api/auth-twitch-callback`
3. Category: Website Integration, Client Type: **Confidential**. Create it, then press **Manage** and copy the **Client ID** and make a **Client Secret**.
4. You also need your channel's numeric ID. Search "Twitch username to ID" and paste your channel name into any converter, or ask me for a way to look it up.

### 5. Add the settings in Vercel
Project > Settings > Environment Variables. Add every name from `.env.example`:

| Name | Value |
|---|---|
| `SITE_URL` | your address with no slash at the end |
| `SESSION_SECRET` | any random 32+ characters |
| `DISCORD_CLIENT_ID`, `DISCORD_CLIENT_SECRET` | from step 3 |
| `DISCORD_GUILD_ID` | your server ID |
| `DISCORD_INVITE` | your invite link (optional) |
| `TWITCH_CLIENT_ID`, `TWITCH_CLIENT_SECRET` | from step 4 |
| `TWITCH_BROADCASTER_ID` | your channel's numeric ID |
| `TWITCH_CHANNEL` | your channel name |
| `ADMIN_TWITCH_ID` and/or `ADMIN_DISCORD_ID` | your own IDs, so you get the Host panel |

Then **Deployments > Redeploy** so the new settings take effect.

### 6. Become the host
Open the site, press **Connect Twitch** (or Discord) with your own account. A **Host panel** button appears at the top.
There you set the prize, end date and links, change points per place, see the private leaderboard, adjust points, and remove entrants or ornaments.
Tick "Show the winner on the page" when the race ends.

Your own Twitch account does not need to pass the subscriber check to open the Host panel, but it cannot play unless it does.

## Things to know
- **Giveaway rules:** a subscriber-only entry can count as paid entry in some places, and Twitch has its own giveaway rules. The page offers a free way to enter on request. Check your local law and Twitch's policy.
- **Re-checking the winner:** subscriptions are checked when someone connects, and sessions last 3 days. Before paying out, ask the winner to press "Check again" or confirm their sub on Twitch.
- **Tuning games:** score tiers and limits are in `lib/config.js`. Change `DAILY_PLAYS` in Vercel to allow more or fewer point-earning plays per day.
- **Privacy:** the site stores Twitch name and ID, Discord name and ID, points and ornament. It never sees passwords. Remove a person from the Host panel to delete their data.
- **Ornaments:** each verified person has one ornament. Saving a new one replaces the old one.
